// SquareLine LVGL GENERATED FILE
// EDITOR VERSION: SquareLine Studio 1.1.0
// LVGL VERSION: 8.2
// PROJECT: EspDisplayS3_test

#ifndef _ESPDISPLAYS3_TEST_UI_H
#define _ESPDISPLAYS3_TEST_UI_H

#ifdef __cplusplus
extern "C" {
#endif

#if defined __has_include
#if __has_include("lvgl.h")
#include "lvgl.h"
#elif __has_include("lvgl/lvgl.h")
#include "lvgl/lvgl.h"
#else
#include "lvgl.h"
#endif
#else
#include "lvgl.h"
#endif

extern lv_obj_t * ui_Main;
extern lv_obj_t * ui_CpuBar;
extern lv_obj_t * ui_CpuLabel;
extern lv_obj_t * ui_GpuLabel;
extern lv_obj_t * ui_GpuBar;






void ui_init(void);

#ifdef __cplusplus
} /*extern "C"*/
#endif

#endif
